
import java.util.Scanner;
// class admin
class user {
    private String nama;
    private String nim;

    // construktor admin
    public user(String nama, String nim) {
        this.nama = nama;
        this.nim = nim;
    }
    // setter dingge input data gak kanggo mending construct
    public void setNama(String nama) {
        this.nama = nama;
    }
    public void setNim(String nim) {
        this.nim = nim;
    }
    //getter dingge output data
    public String getNama() {
        return nama;
    }
    public String getNim() {
        return nim;
    }
    // login & displayInfo pajangan
    public boolean login() {
        return false;
    }
    public void displayInfo(){}
}

class admin extends user {
    String username;
    String password;

    public admin(String nama, String nim, String username, String password) {
        super(nama, nim);
        this.username = username;
        this.password = password;
    }

    @Override
    public boolean login(){
        final String validUsername = "admin082"; // final
        String validPassword = "password082";

        return username.equals(validUsername) && password.equals(validPassword);
    }

    @Override
    public void displayInfo(){
        if (login()){
            System.out.println("Login Admin berhasil!");
        } else {
            System.out.println("Login gagal! Username atau password salah.");
        }
    }
}

class mahasiswa extends user {

    public mahasiswa(String nama, String nim) {
        super(nama, nim);
    }

    @Override
    public boolean login(){
        String validNama = "ryan ahmad setiawan";
        String validNim = "202410370110082";

        return getNama().equals(validNama) && getNim().equals(validNim);
    }

    @Override
    public void displayInfo(){
        if (login()){
            System.out.println("Login Mahasiswa berhasil!");
        } else {
            System.out.println("Login gagal! Nama atau NIM salah.");
        }
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Pilih login:");
        System.out.println("1. Admin");
        System.out.println("2. Mahasiswa");
        System.out.print("Masukkan pilihan: ");
        int pilihan = scanner.nextInt();
        scanner.nextLine();

        if (pilihan == 1) {
            System.out.print("Masukkan username: ");
            String username = scanner.nextLine();
            System.out.print("Masukkan password: ");
            String password = scanner.nextLine();
            // inisialisasi admin ke main
            admin admin = new admin("null","null",username, password);
            admin.login();
            admin.displayInfo();
        } else if (pilihan == 2) {
            System.out.print("Masukkan Nama: ");
            String nama = scanner.nextLine();
            System.out.print("Masukkan NIM: ");
            String nim = scanner.nextLine();
            // inisialisasi mahasiswa ke main
            mahasiswa mahasiswa = new mahasiswa(nama, nim);
            mahasiswa.displayInfo();
        } else {
            System.out.println("Pilihan tidak valid.");
        }
    }
}
